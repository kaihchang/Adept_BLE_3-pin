# Adept_BLE_3-pin
Took open source Adept BLE design and altered PCB &amp; casing for 3-pin micro switches.
